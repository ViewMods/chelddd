extern char* conCu;
